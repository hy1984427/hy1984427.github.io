var should = require('chai').should(),
  expect = require('chai').expect,
  supertest = require('supertest'),
  api = supertest('http://localhost:3000');
describe('User', function() {
  it('should return a response with HTTP code 500 and its content if request the gender of "Yong" as "name"', function(done) {
    api.post('/users/2').set('Accept', 'application/json').send({name:"Yong"}).expect(500).end(function(err,res){
      if (err) return done(err);
      expect(res.error.text).to.equal("Internal Server Error");
      done(err);
    });
  });
});
