var should = require('chai').should(),
  expect = require('chai').expect,
  supertest = require('supertest'),
  api = supertest('http://localhost:3000');
describe('User', function() {
  it('should return a response with HTTP code 200, and the response text should be "Male" if request the gender of "Yale" as "name"', function(done) {
    api.put('/users/1').set('Accept', 'application/json').send({name:"Yale"}).expect(200).end(function(err,res){
      expect(res.body).to.have.property("gender");
      expect(res.body.gender).to.equal("Male");
      done(err);
    });
  });
  
  it('should return a response with HTTP code 500 and its content if request the gender of "Yong" as "name"', function(done) {
    api.post('/users/2').set('Accept', 'application/json').send({name:"Yong"}).expect(500).end(function(err,res){
      if (err) return done(err);
      expect(res.error.text).to.equal("Internal Server Error");
      done(err);
    });
  });
});
