When /^I trigger to see "([^"]*)" message$/ do |buttonLabel|
step "I touch \"#{buttonLabel}\""
end

When /^I fill "([^"]*)" as "([^"]*)"$/ do |name, input|
    step "I use the keyboard to fill in the textfield marked \"#{input}\" with \"#{name}\""
end
                             
When /^I use the keyboard to fill in the textfield marked "([^\\"]*)" with "([^\\"]*)"$/ do |text_field_mark, text_to_type|
    text_field_selector =  "view marked:'#{text_field_mark}'"
    check_element_exists( text_field_selector )
    touch( text_field_selector )
    frankly_map( text_field_selector, 'setText:', text_to_type )
    frankly_map( text_field_selector, 'endEditing:', true )
end

Then /^I can see "([^"]*)"$/ do |welcomeMessage|
#step "I save a screenshot with prefix \"#{welcomeMessage}\""
#step  "I dump the DOM"
#debugger
#step "I should see \"Hello,\""
step "I should see \"#{welcomeMessage}\""
#check_element_exists("view marked:\"Hello,\" parent view:'UITextField'")
#check_element_exists("view marked:\"#{welcomeMessage}\" parent view:'UITextField'")
#step "I should see an element of class \"UITextField\" with name \"Hello\" with the following labels: \"\""
#step "I should see 2 Hello"
#check_element_exists("view:'UIView' marked:'label'")
end

Then /^I should see (.*) Hello$/ do |count|
    hellos = frankly_map( "label marked:'Hello'", 'tag' )
    hellos.count.should == count.to_i
end

Then /^I save a screenshot with prefix "([^"]*)"$/ do |prefix|
#save screenshot of the app (just the screen)
    timestamp = Time.now.strftime("%F_%H-%M-%S.%L")
    filename="#{prefix}_#{timestamp}.png"
    filepath = File.expand_path( File.join("screenshots", filename ) )
    frankly_screenshot(filepath)
end