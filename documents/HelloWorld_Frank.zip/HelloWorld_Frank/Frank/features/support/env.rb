require 'frank-cucumber'
require 'ruby-debug'

Frank::Cucumber::FrankHelper.use_shelley_from_now_on

# TODO: set this constant to the full path for your Frankified target's app bundle.
# See the "Given I launch the app" step definition in launch_steps.rb for more details
APP_BUNDLE_PATH ="~/Library/Developer/Xcode/DerivedData/HelloWorld-gwqdbhsifcegpcdfbgucouujhfio/Build/Products/Debug-iphonesimulator/HelloWorld\ copy.app"

include Frank::Cucumber::FrankHelper
#start_recording
#at_exit do
    #    stop_recording
#end