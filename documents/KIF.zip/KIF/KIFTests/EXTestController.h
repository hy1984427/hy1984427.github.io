//
//  EXTestController.h
//  HelloWorld
//
//  Created by twer on 4/24/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KIFTestController.h"

@interface EXTestController : KIFTestController {}

@end