//
//  EXTestController.m
//  HelloWorld
//
//  Created by twer on 4/24/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "EXTestController.h"
#import "KIFTestScenario+EXAdditions.h"

@implementation EXTestController

- (void)initializeScenarios;
{
    // If your app is doing anything interesting with parameterized scenarios,
    // you'll want to override this method and add them manually.
    [self addScenario:[KIFTestScenario scenarioDefaultValue]];
    [self addScenario:[KIFTestScenario scenarioCustomizedValue]];
    [self addScenario:[KIFTestScenario scenarioEmptyValue]];
    
    // If you're not, 
    //[super initializeScenarios];
}

@end
