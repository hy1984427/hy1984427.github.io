//
//  KIFTestScenario+EXAdditions.h
//  HelloWorld
//
//  Created by twer on 4/24/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KIFTestScenario.h"

@interface KIFTestScenario (EXAdditions)

+ (id)scenarioDefaultValue;
+ (id)scenarioCustomizedValue;
+ (id)scenarioEmptyValue;

@end
