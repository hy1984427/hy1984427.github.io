package com.calculator.test;

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.calculator.Main;
import com.calculator.R;

public class InstrumentationTests extends
		ActivityInstrumentationTestCase2<Main> {

	public InstrumentationTests() {
		super("com.calculator", Main.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testMultiplyResult() {
		final Activity mActivity = this.getActivity();
		final EditText mFirstText = (EditText) mActivity
				.findViewById(R.id.EditText01);
		final EditText mSecondText = (EditText) mActivity
				.findViewById(R.id.EditText02);
		final Button mButton = (Button) mActivity.findViewById(R.id.Button01);
		final TextView mView = (TextView) mActivity
				.findViewById(R.id.TextView01);
		mActivity.runOnUiThread(new Runnable() {
			public void run() {
				mFirstText.setText("10");
				mSecondText.setText("20");
				mButton.performClick();
				assertEquals("200.00", mView.getText().toString());
			}
		});
	}

	@Override
	protected void tearDown() throws Exception {

	}
}