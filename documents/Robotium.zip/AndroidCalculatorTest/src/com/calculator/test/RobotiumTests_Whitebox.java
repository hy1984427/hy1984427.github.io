package com.calculator.test;

import java.util.ArrayList;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.EditText;
import android.widget.TextView;
import com.calculator.R;
import com.calculator.Main;
import com.jayway.android.robotium.solo.Solo;

public class RobotiumTests_Whitebox extends
		ActivityInstrumentationTestCase2<Main> {
	private Solo solo;

	public RobotiumTests_Whitebox() {
		super("com.calculator", Main.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		solo = new Solo(getInstrumentation(), getActivity());
	}

	public void testMultiplyResult() {

		float firstNumber = 10;
		float secondNumber = 20;
		float resutl = firstNumber * secondNumber;

		EditText FirsteditText = (EditText) solo.getView(R.id.EditText01);
		solo.enterText(FirsteditText, String.valueOf(firstNumber));

		EditText SecondeditText = (EditText) solo.getView(R.id.EditText02);
		solo.enterText(SecondeditText, String.valueOf(secondNumber));

		solo.clickOnButton("Multiply");

		assertTrue(solo.searchText(String.valueOf(resutl)));

		TextView outputField = (TextView) solo.getView(R.id.TextView01);

		ArrayList<TextView> currentTextViews = solo
				.getCurrentTextViews(outputField);
		assertFalse(currentTextViews.isEmpty());

		TextView output = (TextView) currentTextViews.get(0);

		assertEquals(String.valueOf(resutl), output.getText().toString());
	}

	@Override
	protected void tearDown() throws Exception {

		solo.finishOpenedActivities();
	}
}