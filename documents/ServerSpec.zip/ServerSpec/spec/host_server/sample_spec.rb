require 'spec_helper'

describe file('/etc/passwd') do
  it { should be_file }
  it { should exist }
  it { should be_owned_by 'root' }
  it { should contain 'root' }
  it { should be_mode 644 }
end

describe file('/tmp') do
  it { should be_directory }
end

describe group('ec2') do
  it { should exist }
  it { should have_gid 1001 }
end

describe package('python-backports-1.0-8.el7.x86_64') do
  it { should be_installed }
end

describe process('rcu_sched') do
  its(:user) { should eq "root" }
  its(:stat) { should eq "R" }
end

describe service('postfix') do
  it { should be_enabled }
  it { should be_running }
end

describe service('ntpd') do
  it { should be_running }
end

describe port(22) do
  it { should be_listening.with('tcp') }
end

describe file"/var/run/docker.sock" do
  it { should be_socket }
end

describe 'Linux kernel parameters' do
  context linux_kernel_parameter('kernel.hostname') do
    its(:value) { should eq "hostname" }
  end

  context linux_kernel_parameter('kernel.osrelease') do
    its(:value) { should eq "3.10.0-693.el7.x86_64" }
  end

  context linux_kernel_parameter('kernel.ostype') do
    its(:value) { should eq "Linux" }
  end
end

describe user"ec2" do
  it { should exist }
  it { should have_uid 1001 }
  it { should have_home_directory "/home/ec2" }
end

describe command"id -nu" do
  its(:stdout) { should match "root" }
end
